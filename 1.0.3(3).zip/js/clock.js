window.onload = function (){
	var d = new Date();
	var n = d.getSeconds() * 6;
	var t = "rotate(" + n + "deg)";
	var ds = document.getElementById("clockS");
	ds.style.transform = t;
	n = d.getMinutes() * 6 + d.getSeconds() * 0.1;
	t = "rotate(" + n + "deg)";
	var dm = document.getElementById("clockM");
	dm.style.transform = t;
	n = d.getHours() * 30 + d.getMinutes() * 0.5;
	t = "rotate(" + n + "deg)";
	var dh = document.getElementById("clockH");
	dh.style.transform = t;
}